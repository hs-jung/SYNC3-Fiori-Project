sap.ui.define([
	"condition_monitoring/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
