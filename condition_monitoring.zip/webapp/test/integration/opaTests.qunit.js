/* global QUnit */

sap.ui.require(["conditionmonitoring/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
